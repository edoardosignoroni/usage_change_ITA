# -*- coding: utf-8 -*-
"""
Created on Tue Dec 29 16:23:21 2020

@author: Edo
"""

import os

year = 2019
directory = r'C:\Users\Edo\Tesi\days_{}'.format(year)
directory_days = r'C:\Users\Edo\Tesi\days_{}\raw'.format(year)
file_list =[]
file_list_raw = []

for entry in os.scandir(directory):
    if entry.path.endswith("{}.txt".format(year)):
        file_list.append(entry)
        
for entry in os.scandir(directory_days):
    if entry.path.endswith("{}.txt".format(year)):
        file_list_raw.append(entry)

for file in file_list:
    file_name = str(os.path.basename(file)).strip('.txt')
    file = open(file,'r', encoding = 'utf-8')
    text = file.read().split(' ')
    print('N_Tokens:', len(text),'\n'+'N_days:', len(file_list_raw), file=open('days_{}\{}_meta.txt'.format(year, file_name), 'w+', encoding='utf-8'))
    file.close()
    