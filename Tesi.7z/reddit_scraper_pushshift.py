# -*- coding: utf-8 -*-

import praw
from psaw import PushshiftAPI
import datetime as dt
import time

r = praw.Reddit(client_id = 'z1sHTaSdDhF4HQ',
                      client_secret = 'xS3qUXdvGvZpUiRewMJ9zaNb3aY',
                       password = 'q1w2e3r4t5',
                      user_agent = 'windows:ita_scraper_test.v0.1 (by /u/EdwardGreatlords)',
                       username = 'EdwardGreatlords')
api = PushshiftAPI(r)

start_epoch = int(dt.datetime(2018, 1, 30).timestamp())
end_epoch = int(dt.datetime(2018, 5, 7).timestamp())

submissions = list(api.search_submissions(before= end_epoch, after=start_epoch, subreddit='italy'))

print(len(submissions))


# All the posts and comments, without the BOT ones. Comments of megathreads and stickied submissions. Title and post taken only one time. All divided by day.
for submission in submissions:
    
    file_name = 'days_2018\day_{}_2018.txt'.format(time.gmtime(submission.created_utc).tm_yday)
        
    if submission.stickied: #evita doppioni e vedi sotto
    
        print ('date: {}'.format(time.gmtime(submission.created_utc).tm_yday))
        
        submission.comments.replace_more(limit=None)
        
        for comment in submission.comments.list():
            
            if not comment.stickied: #la maggior parte dei post dei bot è sticky
            
                if comment.author != 'RedditItalyBot' and comment.author != 'AutoModerator': #non sembra funzionare
            
                    print (comment.body, file=open(file_name, 'a+', encoding = 'utf-8', errors = 'ignore'))               
               
    else:
        
        print ('date: {}'.format(time.gmtime(submission.created_utc).tm_yday))
        print (submission.title, file=open(file_name, 'a+', encoding = 'utf-8', errors = 'ignore'))
        print (submission.selftext, file=open(file_name, 'a+', encoding = 'utf-8', errors = 'ignore'))
        
        submission.comments.replace_more(limit=None)
            
        for comment in submission.comments.list():
            
            if not comment.stickied:
                           
                if comment.author != 'RedditItalyBot' and comment.author != 'AutoModerator':
              
                    print (comment.body, file=open(file_name, 'a+', encoding = 'utf-8', errors = 'ignore'))               
               
                # if len(comment.replies) > 0:
                #     for reply in comment.replies:
                #         print(reply.body, file=open(file_name, 'a+', encoding = 'utf-8', errors = 'ignore'))
        
        # print(r.auth.limits)

file = open(file_name, 'a+')
file.close()
print ("___FINISHED___ ")
    
           