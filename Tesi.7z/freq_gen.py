# -*- coding: utf-8 -*-
"""
Created on Tue Jan  5 15:25:20 2021

@author: Edo
"""

#Generates .csv files with word counts for each day file