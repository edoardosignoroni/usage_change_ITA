# -*- coding: utf-8 -*-
"""
Created on Tue Mar 30 16:03:20 2021

@author: Edo
"""

import pandas as pd
import matplotlib.pyplot as plt
from wordcloud import WordCloud

# read_file = pd.read_csv (r'C:/Users/Edo/Tesi/days_2020/days_2020_clean.txt', header=None, encoding = 'utf-8')
# read_file.to_csv (r'C:/Users/Edo/Tesi/days_2020/days_2020_csv.csv', index=None, encoding = 'utf-8')

# #create dataframe
# df = pd.read_csv ('C:/Users/Edo/Tesi/days_2020/days_2020_csv.csv')
# df.head()

file = open(r'C:/Users/Edo/Tesi/days_2020/processed/days_2020_sentences.txt', 'r', encoding='utf-8')
text = file.read()

wordcloud = WordCloud(width = 800, height = 800, background_color = 'black', stopwords = ['essere', 'avere', 'ci', 'non', 'il', 'comunque', 'a', 'quindi', 'da', 'poi', 'uno', 'invece', 'già', 'e', 'per', 'perché'], max_words = None
                      , min_font_size = 20).generate(str(text))
#plot the word cloud
fig = plt.figure(figsize = (8,8), facecolor = None)
plt.imshow(wordcloud)
plt.axis('off')
plt.show()